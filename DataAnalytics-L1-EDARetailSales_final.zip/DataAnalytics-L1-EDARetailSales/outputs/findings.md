# Findings

## Dataset and cleaning
- Original dataset: 541,909 transaction lines.
- Exact duplicate rows identified: 0.
- Duplicate rows removed: 0.
- For sales-performance analysis, cancelled invoices, negative quantities/returns, zero quantities, zero/negative prices, and rows with invalid dates were excluded.
- The cleaned analysis dataset contains 530,104 positive-sales transaction lines.
- CustomerID is missing for 132,220 cleaned transaction lines; these rows were retained because CustomerID is not required for transaction-level revenue analysis.
- The source dataset does **not** contain age or gender fields, so age-group and gender analysis cannot be truthfully performed from this dataset.

## Sales trends
- The highest-revenue month is **2011-11**, with revenue of **1,509,496.33**.
- The highest-revenue quarter is **2011Q4**.
- Average revenue per invoice is **534.40**, while median invoice revenue is **303.84**.

## Product and market concentration
- The leading product by units sold is **PAPER CRAFT , LITTLE BIRDIE**, with **80,995** units.
- The United Kingdom accounts for approximately **84.6%** of total revenue.
- The top 10 countries together account for approximately **97.2%** of total revenue.

## Actionable recommendations
1. **Plan inventory and campaigns around the strongest periods.** Use the monthly and quarterly peaks to time stock replenishment, staffing, and promotional activity.
2. **Protect high-performing products.** Maintain availability of the strongest-selling products and use complementary-product bundles to increase basket value.
3. **Prioritise the strongest markets while testing international growth.** The revenue concentration by country supports focused retention in major markets, while lower-revenue markets can be tested with targeted campaigns rather than broad spending.
4. **Improve customer-data completeness.** Where commercially appropriate, increase CustomerID capture so customer-level retention, frequency, and lifetime-value analysis becomes more reliable.
